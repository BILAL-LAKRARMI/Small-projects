const API_URL = 'https://670ed5b73e7151861655eaa3.mockapi.io/Stagiaire';
// Tableau fictif stocké en local pour la gestion locale des requêtes (Partie E)
if(!localStorage.getItem('demandes')) {
    localStorage.setItem('demandes', JSON.stringify([]));
}

let currentUser = null;

window.onload = () => {
    currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
    if (!currentUser) {
        window.location.href = 'login.html';
        return;
    }

    // Appliquer la couleur d'arrière-plan lue depuis le stockage client
    document.body.style.backgroundColor = currentUser.couleur || '#ffffff';

    // Header Section Setup
    document.getElementById('userInfo').textContent = `${currentUser.prenom} ${currentUser.nom}`;
    document.getElementById('logoutBtn').onclick = logout;

    renderNavigation();
    loadRoute('accueil'); // Page par défaut
};

function logout() {
    sessionStorage.removeItem('currentUser');
    window.location.href = 'login.html';
}

function renderNavigation() {
    const navContainer = document.getElementById('navContainer');
    const isAdmin = currentUser.admin === true || currentUser.admin === "true";
    
    // Démonstration des deux types demandés: NavigationBar (horizontal) et Index (vertical)
    // On met en place une barre horizontale par défaut mais adaptable
    let navHTML = `<nav class="horizontal">`;
    
    navHTML += `<a href="#" onclick="loadRoute('accueil')">Accueil</a>`;
    navHTML += `<a href="#" onclick="loadRoute('profile')">Voir Mon Profile</a>`;
    navHTML += `<a href="#" onclick="loadRoute('modifierCouleur')">Modifier Couleur</a>`;
    navHTML += `<a href="#" onclick="loadRoute('demandes')">Mes Demandes (Partie E)</a>`;

    if (isAdmin) {
        navHTML += `<a href="#" onclick="loadRoute('listeUtilisateurs')">Liste Utilisateurs (Admin)</a>`;
        navHTML += `<a href="#" onclick="loadRoute('ajouterUtilisateur')">Ajouter Utilisateur (Admin)</a>`;
    }
    
    navHTML += `</nav>`;
    navContainer.innerHTML = navHTML;
}

// Routeur SPA Simple
function loadRoute(route, param = null) {
    const content = document.getElementById('contentSection');
    const isAdmin = currentUser.admin === true || currentUser.admin === "true";

    switch(route) {
        case 'accueil':
            content.innerHTML = `<h2>Bienvenue, ${currentUser.prenom}!</h2><p>Vous êtes connecté au Mini-Projet JavaScript de développement digital.</p>`;
            break;
            
        case 'profile':
            content.innerHTML = `
                <h2>Mon Profil (Lecture seule)</h2>
                <p><strong>Nom:</strong> ${currentUser.nom}</p>
                <p><strong>Prénom:</strong> ${currentUser.prenom}</p>
                <p><strong>Âge:</strong> ${currentUser.age} ans</p>
                <p><strong>Pseudo:</strong> ${currentUser.pseudo}</p>
                <p><strong>Email:</strong> ${currentUser.email}</p>
                <p><strong>Pays:</strong> ${currentUser.Pays}</p>
                <p><strong>Devise:</strong> ${currentUser.Devise}</p>
                <p><strong>Rôle:</strong> ${isAdmin ? 'Administrateur' : 'Visiteur'}</p>
            `;
            break;

        case 'modifierCouleur':
            renderModifierCouleur(content);
            break;

        case 'listeUtilisateurs':
            if(!isAdmin) { content.innerHTML = "Accès refusé."; break; }
            renderListeUtilisateurs(content);
            break;

        case 'ajouterUtilisateur':
            if(!isAdmin) { content.innerHTML = "Accès refusé."; break; }
            renderAjouterUtilisateurForm(content);
            break;

        case 'detailsUtilisateur':
            renderDetailsUtilisateur(content, param);
            break;

        case 'modifierUtilisateur':
            renderModifierUtilisateurForm(content, param);
            break;

        case 'demandes':
            renderDemandesSystem(content);
            break;
    }
}

// --- PARTIE D: Modifier Couleur ---
function renderModifierCouleur(container) {
    const isVisitor = !(currentUser.admin === true || currentUser.admin === "true");
    const age = parseInt(currentUser.age);

    if (isVisitor && age < 15) {
        container.innerHTML = `<h2>Modifier Couleur</h2><p style="color:red;">Désolé, les visiteurs de moins de 15 ans ne peuvent pas modifier la couleur.</p>`;
        return;
    }

    container.innerHTML = `
        <h2>Modifier ma Couleur Préférée</h2>
        <p>Couleur actuelle: <strong>${currentUser.couleur}</strong></p>
        <select id="newCouleurSelect">
            <option value="maroon" ${currentUser.couleur==='maroon'?'selected':''}>Maroon</option>
            <option value="teal" ${currentUser.couleur==='teal'?'selected':''}>Teal</option>
            <option value="blue" ${currentUser.couleur==='blue'?'selected':''}>Blue</option>
            <option value="darkgreen" ${currentUser.couleur==='darkgreen'?'selected':''}>Dark Green</option>
            <option value="purple" ${currentUser.couleur==='purple'?'selected':''}>Purple</option>
        </select>
        <br><br>
        <button id="saveCouleurBtn" style="padding:10px; background:green; color:white; border:none; cursor:pointer;">Valider le changement</button>
    `;

    document.getElementById('saveCouleurBtn').onclick = async () => {
        const selectValue = document.getElementById('newCouleurSelect').value;
        
        try {
            const response = await fetch(`${API_URL}/${currentUser.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...currentUser, couleur: selectValue })
            });
            if(response.ok) {
                currentUser.couleur = selectValue;
                sessionStorage.setItem('currentUser', JSON.stringify(currentUser));
                document.body.style.backgroundColor = selectValue;
                alert("Couleur mise à jour avec succès !");
                loadRoute('modifierCouleur');
            }
        } catch(err) {
            alert("Erreur de synchronisation API.");
        }
    };
}

// --- PARTIE D: Admin CRUD (Read All) ---
async function renderListeUtilisateurs(container) {
    container.innerHTML = `<h2>Gestion des Utilisateurs (CRUD)</h2><p>Chargement en cours...</p>`;
    try {
        const res = await fetch(API_URL);
        const users = await res.json();
        
        let html = `
            <table>
                <thead>
                    <tr>
                        <th>ID</th><th>Nom</th><th>Prénom</th><th>Pseudo</th><th>Rôle</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
        `;
        
        users.forEach(u => {
            html += `
                <tr>
                    <td>${u.id}</td>
                    <td>${u.nom}</td>
                    <td>${u.prenom}</td>
                    <td>${u.pseudo}</td>
                    <td>${(u.admin === true || u.admin === "true") ? 'Admin' : 'Visiteur'}</td>
                    <td>
                        <button class="btn-action btn-view" onclick="loadRoute('detailsUtilisateur', '${u.id}')">Détails</button>
                        <button class="btn-action btn-edit" onclick="loadRoute('modifierUtilisateur', '${u.id}')">Modifier</button>
                        <button class="btn-action btn-delete" onclick="deleteUser('${u.id}')">Supprimer</button>
                    </td>
                </tr>
            `;
        });
        
        html += `</tbody></table>`;
        container.innerHTML = html;
    } catch(err) {
        container.innerHTML = `<p style="color:red;">Erreur lors du chargement des données.</p>`;
    }
}

// --- PARTIE D: Admin CRUD (Read One) ---
async function renderDetailsUtilisateur(container, id) {
    try {
        const res = await fetch(`${API_URL}/${id}`);
        const u = await res.json();
        container.innerHTML = `
            <h2>Détails Utilisateur #${u.id}</h2>
            <p><strong>Nom Complet:</strong> ${u.prenom} ${u.nom}</p>
            <p><strong>Pseudo:</strong> ${u.pseudo}</p>
            <p><strong>Email:</strong> ${u.email}</p>
            <p><strong>Âge:</strong> ${u.age}</p>
            <p><strong>Pays:</strong> ${u.Pays} (${u.Devise})</p>
            <button onclick="loadRoute('listeUtilisateurs')" style="padding:8px; background:#333; color:white; border:none; cursor:pointer;">Retour à la liste</button>
        `;
    } catch (err) {
        container.innerHTML = `<p style="color:red;">Erreur de chargement.</p>`;
    }
}

// --- PARTIE D: Admin CRUD (Create) ---
function renderAjouterUtilisateurForm(container) {
    container.innerHTML = `
        <h2>Ajouter un Nouvel Utilisateur</h2>
        <form id="addUserForm" style="max-width:300px;">
            <input type="text" id="addNom" placeholder="Nom" required style="width:100%; padding:6px; margin:5px 0;"><br>
            <input type="text" id="addPrenom" placeholder="Prénom" required style="width:100%; padding:6px; margin:5px 0;"><br>
            <input type="number" id="addAge" placeholder="Âge" required style="width:100%; padding:6px; margin:5px 0;"><br>
            <input type="text" id="addPseudo" placeholder="Pseudo" required style="width:100%; padding:6px; margin:5px 0;"><br>
            <input type="password" id="addPwd" placeholder="Mot de passe" required style="width:100%; padding:6px; margin:5px 0;"><br>
            <button type="submit" style="padding:10px; background:blue; color:white; border:none; width:100%;">Créer via API</button>
        </form>
    `;
    
    document.getElementById('addUserForm').onsubmit = async (e) => {
        e.preventDefault();
        const payload = {
            id: Math.random().toString(),
            nom: document.getElementById('addNom').value,
            prenom: document.getElementById('addPrenom').value,
            age: parseInt(document.getElementById('addAge').value),
            pseudo: document.getElementById('addPseudo').value,
            MotDePasse: document.getElementById('addPwd').value,
            admin: false, couleur: "maroon"
        };
        
        const res = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        if(res.ok) {
            alert('Utilisateur ajouté avec succès !');
            loadRoute('listeUtilisateurs');
        }
    };
}

// --- PARTIE D: Admin CRUD (Update) ---
async function renderModifierUtilisateurForm(container, id) {
    const res = await fetch(`${API_URL}/${id}`);
    const u = await res.json();
    
    container.innerHTML = `
        <h2>Modifier Utilisateur #${u.id}</h2>
        <form id="editUserForm" style="max-width:300px;">
            <input type="text" id="editNom" value="${u.nom}" required style="width:100%; padding:6px; margin:5px 0;"><br>
            <input type="text" id="editPrenom" value="${u.prenom}" required style="width:100%; padding:6px; margin:5px 0;"><br>
            <input type="number" id="editAge" value="${u.age}" required style="width:100%; padding:6px; margin:5px 0;"><br>
            <button type="submit" style="padding:10px; background:orange; color:white; border:none; width:100%;">Modifier via API</button>
        </form>
    `;

    document.getElementById('editUserForm').onsubmit = async (e) => {
        e.preventDefault();
        const updatedData = {
            ...u,
            nom: document.getElementById('editNom').value,
            prenom: document.getElementById('editPrenom').value,
            age: document.getElementById('editAge').value
        };

        const putRes = await fetch(`${API_URL}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updatedData)
        });
        if(putRes.ok) {
            alert('Modifié avec succès !');
            loadRoute('listeUtilisateurs');
        }
    };
}

// --- PARTIE D: Admin CRUD (Delete) ---
async function deleteUser(id) {
    if(confirm("Voulez-vous vraiment supprimer cet utilisateur ?")) {
        const res = await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
        if(res.ok) {
            alert('Utilisateur supprimé.');
            loadRoute('listeUtilisateurs');
        }
    }
}

// --- PARTIE E: Gestion des Demandes ---
function renderDemandesSystem(container) {
    const isAdmin = currentUser.admin === true || currentUser.admin === "true";
    let demandes = JSON.parse(localStorage.getItem('demandes'));

    if (!isAdmin) {
        // Vue Visiteur / Utilisateur simple
        let userDemandes = demandes.filter(d => d.userId === currentUser.id);
        let listHTML = userDemandes.map(d => `
            <tr>
                <td>${d.titre}</td><td>${d.description}</td><td><strong>${d.statut}</strong></td>
                <td>
                    ${d.statut === 'En attente' ? `<button onclick="annulerDemande('${d.id}')" style="background:red; color:white;">Annuler</button>` : '-'}
                </td>
            </tr>
        `).join('');

        container.innerHTML = `
            <h2>Mes Demandes de Validation</h2>
            <form id="demandeForm" style="max-width:400px; margin-bottom:20px;">
                <input type="text" id="demTitre" placeholder="Titre de la demande" required style="width:100%; padding:6px; margin:5px 0;"><br>
                <textarea id="demDesc" placeholder="Description..." required style="width:100%; padding:6px; margin:5px 0; height:60px;"></textarea><br>
                <button type="submit" style="padding:8px; background:blue; color:white; border:none;">Soumettre la demande</button>
            </form>
            <h3>Historique de mes demandes</h3>
            <table>
                <thead><tr><th>Titre</th><th>Description</th><th>Statut</th><th>Action</th></tr></thead>
                <tbody>${listHTML || '<tr><td colspan="4">Aucune demande.</td></tr>'}</tbody>
            </table>
        `;

        document.getElementById('demandeForm').onsubmit = (e) => {
            e.preventDefault();
            const newDem = {
                id: Math.random().toString(),
                userId: currentUser.id,
                titre: document.getElementById('demTitre').value,
                description: document.getElementById('demDesc').value,
                statut: 'En attente'
            };
            demandes.push(newDem);
            localStorage.setItem('demandes', JSON.stringify(demandes));
            loadRoute('demandes');
        };
    } else {
        // Vue Admin
        let listHTML = demandes.map(d => `
            <tr>
                <td>User #${d.userId}</td><td>${d.titre}</td><td>${d.description}</td><td><strong>${d.statut}</strong></td>
                <td>
                    <button onclick="changerStatutDemande('${d.id}', 'Approuvée')" style="background:green; color:white; margin-right:5px;">Approuver</button>
                    <button onclick="changerStatutDemande('${d.id}', 'Rejetée')" style="background:red; color:white;">Rejeter</button>
                </td>
            </tr>
        `).join('');

        container.innerHTML = `
            <h2>Backoffice de Gestion des Demandes (Admin)</h2>
            <table>
                <thead><tr><th>Utilisateur</th><th>Titre</th><th>Description</th><th>Statut</th><th>Changer l'état</th></tr></thead>
                <tbody>${listHTML || '<tr><td colspan="5">Aucune demande reçue sur la plateforme.</td></tr>'}</tbody>
            </table>
        `;
    }
}

function annulerDemande(id) {
    let demandes = JSON.parse(localStorage.getItem('demandes'));
    demandes = demandes.filter(d => d.id !== id);
    localStorage.setItem('demandes', JSON.stringify(demandes));
    loadRoute('demandes');
}

function changerStatutDemande(id, nouveauStatut) {
    let demandes = JSON.parse(localStorage.getItem('demandes'));
    const dem = demandes.find(d => d.id === id);
    if(dem) {
        dem.statut = nouveauStatut;
        localStorage.setItem('demandes', JSON.stringify(demandes));
        loadRoute('demandes');
    }
}
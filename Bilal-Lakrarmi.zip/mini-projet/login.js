const API_URL = 'https://670ed5b73e7151861655eaa3.mockapi.io/Stagiaire';
let attempts = 0;

window.onload = () => {
    if (localStorage.getItem('rememberedUser')) {
        const saved = JSON.parse(localStorage.getItem('rememberedUser'));
        document.getElementById('username').value = saved.username;
        document.getElementById('password').value = saved.password;
        document.getElementById('rememberMe').checked = true;
    }
};

document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const errorList = document.getElementById('errorList');
    const loginBtn = document.getElementById('loginBtn');
    
    errorList.innerHTML = '';
    let errors = [];

    if (!username) errors.push("Le nom d'utilisateur est obligatoire.");
    if (!password) errors.push("Le mot de passe est obligatoire.");

    if (errors.length > 0) {
        showErrors(errors);
        return;
    }

    try {
        const response = await fetch(API_URL);
        const users = await response.json();
        
        // n-verifier match b pseudo ou email, w m3a MotDePasse
        const user = users.find(u => (u.pseudo === username || u.email === username) && u.MotDePasse === password);

        if (user) {
            sessionStorage.setItem('currentUser', JSON.stringify(user));
            
            if (document.getElementById('rememberMe').checked) {
                localStorage.setItem('rememberedUser', JSON.stringify({ username, password }));
            } else {
                localStorage.removeItem('rememberedUser');
            }
            
            window.location.href = 'app.html';
        } else {
            attempts++;
            errors.push("Identifiants incorrects.");
            if (attempts >= 3) {
                loginBtn.disabled = true;
                errors.push("Bouton bloqué après 3 tentatives infructueuses.");
            }
            showErrors(errors);
        }
    } catch (err) {
        showErrors(["Erreur lors de la connexion à l'API."]);
    }
});

function showErrors(errors) {
    const errorList = document.getElementById('errorList');
    errors.forEach(err => {
        const li = document.createElement('li');
        li.textContent = err;
        errorList.appendChild(li);
    });
}
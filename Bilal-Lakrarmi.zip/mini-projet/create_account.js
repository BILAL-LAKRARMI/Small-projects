const API_URL = 'https://670ed5b73e7151861655eaa3.mockapi.io/Stagiaire';

document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorList = document.getElementById('registerErrors');
    errorList.innerHTML = '';

    const nom = document.getElementById('nom').value.trim();
    const prenom = document.getElementById('prenom').value.trim();
    const age = document.getElementById('age').value.trim();
    const pseudo = document.getElementById('pseudo').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const couleur = document.getElementById('couleur').value;
    const devise = document.getElementById('devise').value.trim();
    const pays = document.getElementById('pays').value.trim();
    const isAdmin = document.getElementById('admin').value === "true";

    let errors = [];

    // Validation des champs obligatoires
    if(!nom || !prenom || !age || !pseudo || !email || !password || !confirmPassword || !devise || !pays) {
        errors.push("Tous les champs sont obligatoires.");
    }

    // Validation Password Regex
    const pwdRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!pwdRegex.test(password)) {
        errors.push("Le mot de passe doit faire au moins 8 caractères, inclure une majuscule, une minuscule, un chiffre et un caractère spécial.");
    }

    if (password !== confirmPassword) {
        errors.push("Les mots de passe ne correspondent pas.");
    }

    if (errors.length > 0) {
        errors.forEach(err => {
            const li = document.createElement('li');
            li.textContent = err;
            errorList.appendChild(li);
        });
        return;
    }

    const newUser = {
        nom, prenom, age, pseudo, email,
        MotDePasse: password,
        couleur, Devise: devise, Pays: pays,
        admin: isAdmin,
        avatar: "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/831.jpg",
        photo: "https://loremflickr.com/640/480/people"
    };

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newUser)
        });

        if (response.ok) {
            alert("Compte créé avec succès !");
            window.location.href = 'login.html';
        } else {
            throw new Error();
        }
    } catch (err) {
        const li = document.createElement('li');
        li.textContent = "Erreur de serveur lors de la création.";
        errorList.appendChild(li);
    }
});